package com.shield.antivirus

import android.content.Context
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicInteger

/** Liste des domaines malveillants + compteurs pour l'interface. */
object Blocklist {
    private val domains: MutableSet<String> = ConcurrentHashMap.newKeySet()
    private const val FEED = "https://urlhaus.abuse.ch/downloads/hostfile/"

    val blockedCount = AtomicInteger(0)
    val recent = ArrayDeque<String>()

    // Domaines de test : ouvre http://blocked.shield.test dans Chrome pour verifier.
    private val builtin = listOf(
        "blocked.shield.test",
        "malware.shield.test",
        "phishing.shield.test"
    )

    fun load(ctx: Context) {
        domains.addAll(builtin)
        val f = File(ctx.filesDir, "blocklist.txt")
        if (f.exists()) parse(f.readLines())
    }

    /** A appeler AVANT d'etablir le VPN (sinon le DNS de l'appli passe par le filtre). */
    fun update(ctx: Context) {
        try {
            val c = URL(FEED).openConnection() as HttpURLConnection
            c.connectTimeout = 8000
            c.readTimeout = 15000
            val lines = c.inputStream.bufferedReader().readLines()
            File(ctx.filesDir, "blocklist.txt").writeText(lines.joinToString("\n"))
            parse(lines)
        } catch (_: Exception) {
            // pas de reseau : on garde la liste en cache
        }
    }

    private fun parse(lines: List<String>) {
        for (l in lines) {
            if (l.startsWith("#") || l.isBlank()) continue
            val parts = l.trim().split(Regex("\\s+"))
            val host = if (parts.size >= 2) parts[1] else parts[0]
            domains.add(host.lowercase())
        }
    }

    fun isBlocked(name: String): Boolean {
        var d = name
        while (true) {
            if (d in domains) return true
            val i = d.indexOf('.')
            if (i < 0) return false
            d = d.substring(i + 1)
        }
    }

    @Synchronized
    fun log(name: String) {
        blockedCount.incrementAndGet()
        recent.addFirst(name)
        while (recent.size > 20) recent.removeLast()
    }

    fun size() = domains.size
}
