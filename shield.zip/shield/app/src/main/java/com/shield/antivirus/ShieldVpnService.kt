package com.shield.antivirus

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.VpnService
import android.os.ParcelFileDescriptor
import androidx.core.content.ContextCompat
import java.io.FileInputStream
import java.io.FileOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.util.concurrent.Executors

/**
 * Protection temps reel : VPN local qui ne capte QUE les requetes DNS.
 * Chaque nom de domaine demande par une appli ou le navigateur est compare a la liste noire ;
 * s'il est dangereux, la reponse est "domaine inexistant" et la connexion n'a jamais lieu.
 * Les domaines autorises sont transmis a Quad9 (9.9.9.9), un DNS qui bloque aussi les malwares.
 */
class ShieldVpnService : VpnService() {

    companion object {
        const val ACTION_STOP = "com.shield.antivirus.STOP"
        @Volatile var running = false
        private const val FAKE_DNS = "10.0.0.2"
        private const val UPSTREAM = "9.9.9.9"
    }

    private var tun: ParcelFileDescriptor? = null
    private var reader: Thread? = null
    private val pool = Executors.newFixedThreadPool(8)
    private val lastAlert = HashMap<String, Long>()
    private var receiverRegistered = false

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val pkg = i.data?.schemeSpecificPart ?: return
            val r = AppScanner.scanOne(c, pkg) ?: return
            if (r.level != Level.OK) {
                Notifier.alert(
                    c,
                    "Nouvelle appli ${r.level.label} : ${r.label}",
                    r.reasons.joinToString("\n• ", prefix = "• ")
                )
            }
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(1, Notifier.protection(this))
        Thread {
            Blocklist.load(this)
            Blocklist.update(this) // avant l'ouverture du tunnel
            startTunnel()
        }.start()
        if (!receiverRegistered) {
            val f = IntentFilter(Intent.ACTION_PACKAGE_ADDED).apply { addDataScheme("package") }
            ContextCompat.registerReceiver(this, pkgReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED)
            receiverRegistered = true
        }
        return START_STICKY
    }

    private fun startTunnel() {
        if (tun != null) return
        tun = Builder()
            .setSession("Shield")
            .addAddress("10.0.0.1", 32)
            .addDnsServer(FAKE_DNS)
            .addRoute(FAKE_DNS, 32) // seul le DNS passe par ici
            .setBlocking(true)
            .establish() ?: return
        running = true
        reader = Thread { loop() }.also { it.start() }
    }

    private fun loop() {
        val input = FileInputStream(tun!!.fileDescriptor)
        val output = FileOutputStream(tun!!.fileDescriptor)
        val buf = ByteArray(32767)
        while (running) {
            val len = try { input.read(buf) } catch (_: Exception) { break }
            if (len <= 0) continue
            if ((buf[0].toInt() shr 4) != 4) continue // IPv4 seulement
            val ihl = (buf[0].toInt() and 0x0F) * 4
            if (len < ihl + 8 + 12 || buf[9].toInt() != 17) continue // UDP
            val dstPort = ((buf[ihl + 2].toInt() and 0xFF) shl 8) or (buf[ihl + 3].toInt() and 0xFF)
            if (dstPort != 53) continue
            val req = buf.copyOf(len)
            pool.execute { handle(req, ihl, output) }
        }
    }

    private fun handle(req: ByteArray, ihl: Int, out: FileOutputStream) {
        val dns = req.copyOfRange(ihl + 8, req.size)
        val parsed = parseName(dns) ?: return
        val (name, qEnd) = parsed

        val reply: ByteArray = if (Blocklist.isBlocked(name)) {
            Blocklist.log(name)
            alertOnce(name)
            // Reponse NXDOMAIN : le site "n'existe pas"
            val r = dns.copyOf(qEnd + 4)
            r[2] = 0x81.toByte(); r[3] = 0x83.toByte()
            r[6] = 0; r[7] = 0; r[8] = 0; r[9] = 0; r[10] = 0; r[11] = 0
            r
        } else {
            try {
                DatagramSocket().use { s ->
                    protect(s) // ne repasse pas par le VPN
                    s.soTimeout = 3000
                    val up = InetAddress.getByName(UPSTREAM)
                    s.send(DatagramPacket(dns, dns.size, up, 53))
                    val rb = ByteArray(4096)
                    val p = DatagramPacket(rb, rb.size)
                    s.receive(p)
                    rb.copyOf(p.length)
                }
            } catch (_: Exception) {
                return
            }
        }
        val pkt = buildReply(req, ihl, reply)
        synchronized(out) { try { out.write(pkt) } catch (_: Exception) {} }
    }

    private fun alertOnce(name: String) {
        val now = System.currentTimeMillis()
        val last = synchronized(lastAlert) { lastAlert.put(name, now) } ?: 0L
        if (now - last > 60_000) {
            Notifier.alert(this, "Site dangereux bloque", "$name a ete bloque avant de charger.")
        }
    }

    private fun parseName(d: ByteArray): Pair<String, Int>? {
        var i = 12
        val sb = StringBuilder()
        while (i < d.size) {
            val l = d[i].toInt() and 0xFF
            if (l == 0) return sb.toString().lowercase() to (i + 1)
            if ((l and 0xC0) != 0 || i + 1 + l > d.size) return null
            if (sb.isNotEmpty()) sb.append('.')
            sb.append(String(d, i + 1, l, Charsets.US_ASCII))
            i += l + 1
        }
        return null
    }

    private fun buildReply(req: ByteArray, ihl: Int, dns: ByteArray): ByteArray {
        val udpLen = 8 + dns.size
        val total = 20 + udpLen
        val o = ByteArray(total)
        o[0] = 0x45
        o[2] = (total shr 8).toByte(); o[3] = total.toByte()
        o[8] = 64; o[9] = 17
        System.arraycopy(req, 16, o, 12, 4) // src = ancienne destination
        System.arraycopy(req, 12, o, 16, 4) // dst = ancienne source
        val ck = checksum(o, 20)
        o[10] = (ck shr 8).toByte(); o[11] = ck.toByte()
        o[20] = req[ihl + 2]; o[21] = req[ihl + 3] // ports inverses
        o[22] = req[ihl]; o[23] = req[ihl + 1]
        o[24] = (udpLen shr 8).toByte(); o[25] = udpLen.toByte()
        System.arraycopy(dns, 0, o, 28, dns.size)
        return o
    }

    private fun checksum(b: ByteArray, len: Int): Int {
        var sum = 0
        var i = 0
        while (i < len) {
            sum += ((b[i].toInt() and 0xFF) shl 8) or (b[i + 1].toInt() and 0xFF)
            i += 2
        }
        while (sum shr 16 != 0) sum = (sum and 0xFFFF) + (sum shr 16)
        return sum.inv() and 0xFFFF
    }

    override fun onDestroy() {
        running = false
        try { tun?.close() } catch (_: Exception) {}
        tun = null
        if (receiverRegistered) {
            try { unregisterReceiver(pkgReceiver) } catch (_: Exception) {}
            receiverRegistered = false
        }
        pool.shutdownNow()
        super.onDestroy()
    }

    override fun onRevoke() {
        stopSelf()
    }
}
