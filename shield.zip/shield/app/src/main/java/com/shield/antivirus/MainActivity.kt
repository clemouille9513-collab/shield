package com.shield.antivirus

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.net.VpnService
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {

    private lateinit var status: TextView
    private lateinit var stats: TextView
    private lateinit var toggle: Button
    private lateinit var results: LinearLayout
    private val ui = Handler(Looper.getMainLooper())

    private val vpnPermission = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (it.resultCode == Activity.RESULT_OK) startService(Intent(this, ShieldVpnService::class.java))
    }
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    private val refresh = object : Runnable {
        override fun run() {
            val on = ShieldVpnService.running
            status.text = if (on) "PROTEGE" else "NON PROTEGE"
            status.setTextColor(if (on) Color.rgb(0, 160, 70) else Color.rgb(200, 40, 40))
            toggle.text = if (on) "Desactiver la protection" else "Activer la protection temps reel"
            val recent = synchronized(Blocklist) { Blocklist.recent.take(5).joinToString("\n") { "  - $it" } }
            stats.text = "Sites bloques : ${Blocklist.blockedCount.get()}   |   Liste : ${Blocklist.size()} domaines" +
                (if (recent.isNotEmpty()) "\nDerniers :\n$recent" else "")
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(40, 80, 40, 40)
        }
        root.addView(TextView(this).apply { text = "Shield"; textSize = 30f; setTextColor(Color.BLACK) })
        status = TextView(this).apply { textSize = 22f; setPadding(0, 20, 0, 10) }
        root.addView(status)
        stats = TextView(this).apply { textSize = 14f; setTextColor(Color.DKGRAY) }
        root.addView(stats)

        toggle = Button(this)
        toggle.setOnClickListener {
            if (ShieldVpnService.running) {
                startService(Intent(this, ShieldVpnService::class.java).setAction(ShieldVpnService.ACTION_STOP))
            } else {
                val i = VpnService.prepare(this)
                if (i != null) vpnPermission.launch(i) else startService(Intent(this, ShieldVpnService::class.java))
            }
        }
        root.addView(toggle)

        val scan = Button(this).apply { text = "Scanner mes applis" }
        scan.setOnClickListener { runScan() }
        root.addView(scan)

        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(results)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() { super.onResume(); ui.post(refresh) }
    override fun onPause() { super.onPause(); ui.removeCallbacks(refresh) }

    private fun runScan() {
        results.removeAllViews()
        results.addView(TextView(this).apply { text = "Analyse en cours..." })
        Thread {
            val all = AppScanner.scanAll(this)
            runOnUiThread {
                results.removeAllViews()
                val bad = all.filter { it.level != Level.OK }
                results.addView(TextView(this).apply {
                    textSize = 16f
                    setPadding(0, 30, 0, 10)
                    text = "${all.size} applis analysees : ${bad.size} a verifier"
                })
                for (r in bad) results.addView(card(r))
            }
        }.start()
    }

    private fun card(r: AppReport): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 20, 24, 20)
            setBackgroundColor(if (r.level == Level.DANGER) Color.rgb(255, 225, 225) else Color.rgb(255, 245, 210))
            val lp = LinearLayout.LayoutParams(-1, -2); lp.setMargins(0, 12, 0, 12); layoutParams = lp
        }
        box.addView(TextView(this).apply {
            text = "${r.label}  -  ${r.level.label.uppercase()} (score ${r.score})"
            textSize = 16f; setTextColor(Color.BLACK)
        })
        box.addView(TextView(this).apply {
            text = r.reasons.joinToString("\n") { "- $it" }
            textSize = 13f; setTextColor(Color.DKGRAY)
        })
        val row = LinearLayout(this).apply { gravity = Gravity.END }
        row.addView(Button(this).apply {
            text = "Parametres"
            setOnClickListener {
                startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${r.pkg}")))
            }
        })
        row.addView(Button(this).apply {
            text = "Desinstaller"
            setOnClickListener { startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${r.pkg}"))) }
        })
        box.addView(row)
        return box
    }
}
