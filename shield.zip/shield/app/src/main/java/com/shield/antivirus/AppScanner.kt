package com.shield.antivirus

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageInfo
import android.content.pm.PackageManager

enum class Level(val label: String) { OK("sure"), SUSPECT("suspecte"), DANGER("dangereuse") }

data class AppReport(
    val label: String,
    val pkg: String,
    val score: Int,
    val level: Level,
    val reasons: List<String>
)

/** Analyse les applis installees : permissions a risque, services espions, origine de l'installation. */
object AppScanner {

    private val trustedStores = setOf(
        "com.android.vending",
        "com.sec.android.app.samsungapps",
        "com.amazon.venezia",
        "com.huawei.appmarket"
    )

    fun scanAll(ctx: Context): List<AppReport> {
        val pm = ctx.packageManager
        return pm.getInstalledPackages(flags())
            .filter { it.applicationInfo != null && !isSystem(it.applicationInfo!!) && it.packageName != ctx.packageName }
            .mapNotNull { analyse(pm, it) }
            .sortedByDescending { it.score }
    }

    fun scanOne(ctx: Context, pkg: String): AppReport? = try {
        val pm = ctx.packageManager
        analyse(pm, pm.getPackageInfo(pkg, flags()))
    } catch (_: Exception) {
        null
    }

    private fun flags() = PackageManager.GET_PERMISSIONS or PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS

    private fun isSystem(a: ApplicationInfo) = (a.flags and ApplicationInfo.FLAG_SYSTEM) != 0

    private fun analyse(pm: PackageManager, p: PackageInfo): AppReport? {
        val app = p.applicationInfo ?: return null
        val perms = p.requestedPermissions?.toSet() ?: emptySet()
        var score = 0
        val why = ArrayList<String>()

        fun has(vararg x: String) = x.any { "android.permission.$it" in perms }

        val installer = try {
            pm.getInstallSourceInfo(p.packageName).installingPackageName
        } catch (_: Exception) { null }
        if (installer == null || installer !in trustedStores) {
            score += 2; why += "Installee hors Play Store / Galaxy Store (APK externe)"
        }
        if (p.services?.any { it.permission == "android.permission.BIND_ACCESSIBILITY_SERVICE" } == true) {
            score += 3; why += "Service d'accessibilite : peut lire ton ecran et cliquer a ta place (technique des chevaux de Troie bancaires)"
        }
        if (p.receivers?.any { it.permission == "android.permission.BIND_DEVICE_ADMIN" } == true) {
            score += 3; why += "Administrateur de l'appareil : difficile a desinstaller"
        }
        if (p.services?.any { it.permission == "android.permission.BIND_NOTIFICATION_LISTENER_SERVICE" } == true) {
            score += 2; why += "Peut lire tes notifications (codes SMS, messages)"
        }
        if (has("READ_SMS", "RECEIVE_SMS", "SEND_SMS")) {
            score += 2; why += "Acces aux SMS : peut voler des codes ou envoyer des SMS payants"
        }
        if (has("SYSTEM_ALERT_WINDOW")) {
            score += 2; why += "Peut s'afficher par-dessus d'autres applis (faux ecrans de connexion)"
        }
        if (has("REQUEST_INSTALL_PACKAGES")) {
            score += 1; why += "Peut installer d'autres applis"
        }
        if (has("READ_CONTACTS")) { score += 1; why += "Lit tes contacts" }
        if (has("RECORD_AUDIO")) { score += 1; why += "Peut enregistrer le micro" }
        if (has("CAMERA")) { score += 1; why += "Peut utiliser la camera" }
        if (has("ACCESS_FINE_LOCATION", "ACCESS_BACKGROUND_LOCATION")) {
            score += 1; why += "Suit ta position"
        }

        val level = when {
            score >= 6 -> Level.DANGER
            score >= 3 -> Level.SUSPECT
            else -> Level.OK
        }
        return AppReport(pm.getApplicationLabel(app).toString(), p.packageName, score, level, why)
    }
}
