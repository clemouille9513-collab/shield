package com.shield.antivirus

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent

object Notifier {
    private const val CH_STATUS = "status"
    private const val CH_ALERT = "alert"
    private var nextId = 100

    private fun ensureChannels(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CH_STATUS, "Protection active", NotificationManager.IMPORTANCE_LOW)
        )
        nm.createNotificationChannel(
            NotificationChannel(CH_ALERT, "Alertes de securite", NotificationManager.IMPORTANCE_HIGH)
        )
    }

    private fun openApp(ctx: Context) = PendingIntent.getActivity(
        ctx, 0, Intent(ctx, MainActivity::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun protection(ctx: Context): Notification {
        ensureChannels(ctx)
        return Notification.Builder(ctx, CH_STATUS)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("Shield protege ton telephone")
            .setContentText("Protection en temps reel active")
            .setContentIntent(openApp(ctx))
            .setOngoing(true)
            .build()
    }

    fun alert(ctx: Context, title: String, text: String) {
        ensureChannels(ctx)
        val n = Notification.Builder(ctx, CH_ALERT)
            .setSmallIcon(android.R.drawable.ic_dialog_alert)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(openApp(ctx))
            .setAutoCancel(true)
            .build()
        try {
            ctx.getSystemService(NotificationManager::class.java).notify(nextId++, n)
        } catch (_: SecurityException) {
            // permission notifications refusee
        }
    }
}
