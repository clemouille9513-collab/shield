# Shield – antivirus Android (Kotlin)

## Ce que ça fait vraiment
- **Temps réel** : un VPN local capte uniquement les requêtes DNS. Tout site de la liste noire
  (liste URLhaus mise à jour à chaque activation + domaines de test) est bloqué avant de charger,
  dans Chrome comme dans n'importe quelle appli. Les autres requêtes passent par Quad9 (9.9.9.9),
  un DNS qui bloque aussi les malwares. Aucune donnée ne quitte le téléphone.
- **Scan des applis** : permissions à risque, services d'accessibilité / admin / notifications,
  installation hors store. Chaque appli suspecte est expliquée (« ce que c'est »).
- **Notifications** : site bloqué, nouvelle appli suspecte installée.
- **Éliminer une menace** : boutons « Paramètres » et « Désinstaller » sur chaque appli dangereuse.

## Limites (Android l'interdit, aucun antivirus ne peut)
- Pas de « fausse adresse IP » : seul un serveur VPN distant peut changer ton IP publique.
- Pas d'« attaque » sur les virus ni de lecture des fichiers privés des autres applis : Android les isole.
  Le seul moyen d'éliminer une appli malveillante est de la désinstaller (l'utilisateur confirme).

## Compiler l'APK
1. Installe Android Studio (sur un PC/Mac) et ouvre ce dossier.
2. Attends la synchro Gradle, puis Build > Build APK(s).
3. Envoie l'APK sur le téléphone, installe-le, ouvre Shield.
4. Appuie sur « Activer la protection » et accepte la demande VPN et les notifications.

## Tester
Ouvre `http://blocked.shield.test` dans Chrome : il doit être bloqué et tu reçois une notification.
